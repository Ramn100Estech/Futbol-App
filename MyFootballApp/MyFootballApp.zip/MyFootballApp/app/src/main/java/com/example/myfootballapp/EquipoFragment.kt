package com.example.myfootballapp

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myfootballapp.databinding.FragmentEquipoBinding

class EquipoFragment : Fragment() {

    private lateinit var binding: FragmentEquipoBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentEquipoBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager = LinearLayoutManager(context)
        binding.recyclerView.layoutManager = layoutManager

        val listado = ArrayList<Jugador>()
        listado.add(Jugador(1, "Clua", "David Clua Pumar", "Portero", "07/01/1995", "Vigo", 1.99, 85, "Burgos CF", "", "https://pbs.twimg.com/media/FLqUG2zXIAIGICS?format=jpg&name=small", 1, "escuelaestech"))
        listado.add(Jugador(2, "Lacroux", "Jany Lacroux", "Lateral derecho", "26/02/1996", "Bree (Bélgica)", 1.82, 79, "Genk Sub'19", "Lateral derecho que también se desenvuelve bien como central. Internacional en categorías inferiores con Bélgica", "https://pbs.twimg.com/media/FLGVFofXoAMMysN?format=jpg&name=small", 2, ""))

        
        val adapter = JugadorAdapter()
        binding.recyclerView.adapter = adapter

        adapter.addLista(listado)
    }
}