package com.example.myfootballapp

import android.os.Bundle
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.myfootballapp.databinding.CabeceraBinding
import com.example.myfootballapp.databinding.SecondActivityBinding
import java.text.SimpleDateFormat
import java.util.*


class SecondActivity : AppCompatActivity() {

    private lateinit var binding: SecondActivityBinding
    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SecondActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val b = getIntent().extras
        val user = b!!.getString("user")


        navController = findNavController(R.id.fragmentContainerView)
        appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.homeFragment, R.id.equipoFragment, R.id.contactFragment
            ), binding.DrawerLayout
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        binding.Nav.setupWithNavController(navController)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.DrawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.DrawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    if (!navController.navigateUp())
                        finish()
                }
            }
        })

//          val headerBinding = CabeceraBinding.inflate(layoutInflater)
//          binding.Nav.addHeaderView(headerBinding.root)
            val header = binding.Nav.getHeaderView(0)
            val textoUsuario = header.findViewById<TextView>(R.id.textView6)
            if (user.isNullOrEmpty()){
                textoUsuario.text = "Invitado"
            } else {
                textoUsuario.text = user
            }
            val textoFecha = header.findViewById<TextView>(R.id.textView8)
            textoFecha.text = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.fragmentContainerView)
        return  navController.navigateUp(appBarConfiguration) ||
                super.onSupportNavigateUp()
    }

}